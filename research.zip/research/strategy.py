"""Mechanical, auditable interpretation of the course; not discretionary replication.

Daily macro grid is fixed before the tested period, from the 2023 video example.
The otherwise subjective daily M1 channel is selected with confirmed pivots.
"""
from dataclasses import dataclass, asdict
import math
import numpy as np
import pandas as pd
from engine import Signal


@dataclass(frozen=True)
class Rules:
    macro_low: float = 1803.98
    macro_high: float = 2077.49
    macro_divisions: int = 8
    start_brt_minute: int = 3*60+30
    end_entry_brt_minute: int = 10*60+30
    force_close_brt_minute: int = 12*60
    channel_lookback: int = 60
    pivot_radius: int = 2
    target_levels: int = 2
    max_trades_per_day: int = 3
    stop_buffer_width: float = .10
    daily_direction_filter: bool = True
    large_candle_width_limit: float = 1.5


def prepare_data(path):
    df=pd.read_csv(path).sort_values('time').drop_duplicates('time').reset_index(drop=True)
    # The observed live broker timestamp is UTC+3, not real UTC. Historical
    # server clock is modeled as New York +7h (UTC+2 winter / +3 summer).
    server=pd.to_datetime(df.time,unit='s')
    ny=(server-pd.Timedelta(hours=7)).dt.tz_localize('America/New_York',ambiguous='NaT',nonexistent='shift_forward')
    brt=ny.dt.tz_convert('America/Sao_Paulo')
    df['server_time']=server
    df['brt_time']=brt
    df['brt_minute']=brt.dt.hour*60+brt.dt.minute
    # Use broker daily bar boundaries for daily formation (not Brazilian midnight).
    df['session_day']=server.dt.strftime('%Y-%m-%d')
    df['daily_open']=df.groupby('session_day').open.transform('first')
    return df


def confirmed_pivots(h,l,radius):
    highs=[]; lows=[]
    for i in range(radius,len(h)-radius):
        if h[i]>=max(h[i-radius:i+radius+1]) and h[i]>max(h[i-radius:i]): highs.append((i,float(h[i])))
        if l[i]<=min(l[i-radius:i+radius+1]) and l[i]<min(l[i-radius:i]): lows.append((i,float(l[i])))
    return highs,lows


def channel_at_session_start(history, rules):
    if len(history)<rules.channel_lookback:
        return None
    h=history.high.to_numpy();l=history.low.to_numpy()
    ph,pl=confirmed_pivots(h,l,rules.pivot_radius)
    if len(ph)<2 or len(pl)<2: return None
    # Rising last confirmed top and bottom => bullish; falling => bearish.
    # Mixed structure: direction from last close relative to lookback open.
    up=ph[-1][1]>ph[-2][1] and pl[-1][1]>pl[-2][1]
    down=ph[-1][1]<ph[-2][1] and pl[-1][1]<pl[-2][1]
    direction=1 if up else -1 if down else (1 if history.close.iloc[-1]>=history.open.iloc[0] else -1)
    if direction==1:
        pi,upper=ph[-1]
        levels=[(i,v) for i,v in ph+pl if i<pi and v<upper-.02]
        if not levels:return None
        # Most recent suitable preceding structural level; two tops are allowed
        # by lesson 4. Do not choose retrospectively for the eventual result.
        lower=max(levels,key=lambda x:x[0])[1]
    else:
        pi,lower=pl[-1]
        levels=[(i,v) for i,v in ph+pl if i<pi and v>lower+.02]
        if not levels:return None
        upper=max(levels,key=lambda x:x[0])[1]
    width=upper-lower
    if width<.03:return None
    # CA and ZN form a two-width box; neutral extension follows first trend.
    box_low=lower-width if direction==1 else lower
    box_high=upper if direction==1 else upper+width
    return dict(ca_low=lower,ca_high=upper,width=width,box_low=box_low,
                box_high=box_high,initial_direction=direction,
                history_start=int(history.index[0]),history_end=int(history.index[-1]))


def build_signals(df,rules=Rules()):
    signals=[];channels=[]
    closes=df.close.to_numpy(float)
    daily_opens=df.daily_open.to_numpy(float)
    ranges=(df.high-df.low).to_numpy(float)
    macro_width=(rules.macro_high-rules.macro_low)/rules.macro_divisions
    macro_half=macro_width/2
    for day,part in df.groupby('session_day',sort=True):
        candidates=part[(part.brt_minute>=rules.start_brt_minute)&(part.brt_minute<rules.end_entry_brt_minute)]
        if candidates.empty:continue
        start=int(candidates.index[0])
        history=part.loc[part.index<start].tail(rules.channel_lookback)
        channel=channel_at_session_start(history,rules)
        if channel is None:continue
        channel.update(day=day,start_index=start,macro_width=macro_width)
        channels.append(channel)
        width=channel['width'];low=channel['box_low'];high=channel['box_high']
        shift=0.0
        for i in candidates.index:
            i=int(i)
            if i<start:continue
            prev=float(closes[i-1]);price=float(closes[i])
            side=1 if prev<=high and price>high else -1 if prev>=low and price<low else 0
            if not side:continue
            if rules.large_candle_width_limit and ranges[i]>rules.large_candle_width_limit*width:
                # Lesson 11, ~10m30s: do not chase a >1.5-channel breakout bar.
                # Extend one channel in its direction and await a NEW close.
                low+=side*width;high+=side*width;shift+=side*width
                continue
            if rules.daily_direction_filter and side*(price-float(daily_opens[i]))<=0:continue
            # Require room for at least one micro width before next macro half
            # level. This formalizes lesson 4's 'room to protect the position'.
            k=(price-rules.macro_low)/macro_half
            next_macro=rules.macro_low+(math.floor(k)+1 if side==1 else math.ceil(k)-1)*macro_half
            if side*(next_macro-price)<2*width:continue
            stop=(low-rules.stop_buffer_width*width) if side==1 else (high+rules.stop_buffer_width*width)
            # A projected level is one full box (CA+ZN), not one half-box.
            breakout=high if side==1 else low
            raw_target=breakout+side*rules.target_levels*(high-low)
            target=min(raw_target,next_macro) if side==1 else max(raw_target,next_macro)
            if side*(target-price)<=0:continue
            context={**channel,'box_low':low,'box_high':high,
                     'ca_low':channel['ca_low']+shift,'ca_high':channel['ca_high']+shift,
                     'channel_shift':shift,'next_macro':next_macro,'daily_open':float(daily_opens[i]),
                     'signal_close':price,'macro_half':macro_half,
                     'breakeven_trigger':breakout+side*(high-low),
                     'target_distance':rules.target_levels*(high-low),
                     'subcycle_distance':high-low}
            signals.append(Signal(i,side,stop,target,
                'Fechamento M1 rompe CA+ZN, a favor da vela diaria, com espaco ate o macro',context))
    return signals,channels
