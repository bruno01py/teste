# O que este backtest reproduz

Este trabalho implementa **uma versão mecânica do núcleo de canal de referência
e zona neutra** apresentado na playlist. O curso não define um único algoritmo:
o autor escolhe canais visualmente, combina diário/semanal/M15/M1 e apresenta
alternativas de entrada, alvo e saída. Portanto, o resultado não permite julgar
todas as decisões discricionárias do autor nem todos os setups do curso.

Não se transformaram as operações ilustrativas dos vídeos em uma série
estatística: os preços testados são o histórico da corretora do usuário em
outubro/2025 a outubro/2026. A seleção de cenas dos vídeos pode mostrar exemplos
escolhidos pelo autor e não informa a distribuição completa de ganhos e perdas.

## Fontes do núcleo implementado

Os tempos abaixo são aproximados. As transcrições automáticas preservadas em
`transcripts/` usam minutos decimais; por exemplo, 10,52 min significa ~10m31s.

| Aula e passagem | Regra ensinada | Decisão no programa |
|---|---|---|
| [1, ~5m30](https://www.youtube.com/watch?v=Zu57DaCN9Es&t=330) | Diário como macro, execução no M1 | Mapa diário prévio e candle diário em formação; entrada M1 |
| [2, ~2m46 a 4m34](https://www.youtube.com/watch?v=UkVnD4vhXg8&t=166) | Medir tendência macro e dividir sucessivamente ao meio | Âncoras 1803,98 e 2077,49 visíveis no exemplo de 2023; amplitude / 8 e meias linhas; grade fixa estendida |
| [3, ~8m15](https://www.youtube.com/watch?v=eoHPhQXBKz0&t=495) | Preferência pelo período a partir de 03h30 e até ~10h30 | Janela de entradas 03h30–10h30 em Brasília |
| [4, ~1m29 a 2m34](https://www.youtube.com/watch?v=J1tgyNYbnU0&t=89) | Último topo/fundo e possibilidade de usar dois topos como referências | Pivôs confirmados por 2 velas de cada lado, nos 60 minutos anteriores à sessão; nível anterior adequado |
| [4, ~9m27 a 10m05](https://www.youtube.com/watch?v=J1tgyNYbnU0&t=567) | Manter a marcação M1 durante o dia e apagar no fim | Uma referência por dia; projeções preservam a mesma largura |
| [5, ~5m15 a 6m40](https://www.youtube.com/watch?v=PHjfhRHiGOA&t=315) | Stop fora da caixa; preferência por take de dois níveis; subciclo CA+ZN | Stop além de CA+ZN; alvo de duas caixas; proteção após uma caixa |
| [6, ~8m17](https://www.youtube.com/watch?v=ddXTlW_fFug&t=497) | Projetar a partir da entrada quando a execução vai além da linha | Alvo e subciclo calculados com a entrada efetivamente simulada |
| [7, ~4m22 e 8m25](https://www.youtube.com/watch?v=7_uzmNo1tRI&t=262) | Stop posicionado ou por fechamento; proteger após subciclo | Principal com stop posicionado; fechamento testado separadamente |
| [11, ~10m31 a 11m58](https://www.youtube.com/watch?v=6H7qjWA7CxY&t=631) | Não executar vela maior que 1,5 canal; projetar e esperar novo rompimento | Amplitude máxima–mínima > 1,5 largura: deslocar uma largura, não executar a vela e aguardar novo fechamento |
| [13, ~5m47](https://www.youtube.com/watch?v=wo6Fm3MROI0&t=347) | Esperar fechamento além do subciclo para proteger | Zero a zero somente após fechamento, válido no candle seguinte |
| [14, ~2m26 e 4m53](https://www.youtube.com/watch?v=fB6f4UnXYow&t=146) | Alternativa de stop em médias High/Low de 30 períodos | Variante SMA 30 High/Low, stop por fechamento e saída na abertura seguinte; SMA é hipótese explícita |
| [15, ~4m23 a 5m47](https://www.youtube.com/watch?v=rP_CF9bJ1ZU&t=263) | Reavaliar a direção após o preço retornar e perder a estrutura | A versão permite novo sinal oposto quando a caixa é rompida; filtro diário liga/desliga é comparado |
| [17, ~4m21 e 9m25](https://www.youtube.com/watch?v=R-RAhRirpQU&t=261) | Stop fora da caixa é a preferência; média é alternativa | Mantido o stop técnico como principal, média separada |
| [18, ~5m49 e 9m07](https://www.youtube.com/watch?v=VJ-k6st6UcM&t=349) | Subciclo M1 de dois canais e manter take/stop | Proteção por uma caixa CA+ZN, sem saída manual por valor em dinheiro |

Foram transcritas e examinadas as 20 aulas. As aulas 8–10 incluem comportamento,
barra elefante e lateralização; a 12 e a 19 combinam ciclos semanais/M15 com
antecipação M1; a 13 aborda a rabelada e alternativas de saída; a 16 mostra alvo
por projeção e contexto. São possibilidades, não uma única combinação obrigatória.

A [aula 20, ~7m35 e 12m43](https://www.youtube.com/watch?v=FwvQZFlrbMs&t=455)
apresenta uma conta aritmética de crescimento, mencionando uma estratégia de
recuperação que não é especificada nesse vídeo. Ela não fornece um histórico
completo de operações nem um algoritmo de recuperação reproduzível. Esse plano
não foi tratado como prova de rentabilidade e não foi inventada uma recuperação
para completar o teste.

As duas âncoras macro do cenário principal são anteriores ao período testado;
elas não foram escolhidas pelos resultados de 2025–2026. A grade é uma
regularização matemática do desenho manual, que tem pequenas diferenças de
posicionamento nas cenas. Também se testa uma grade alternativa baseada na
referência semanal 1762–1878 citada repetidamente no curso. Não se escolheu a
melhor grade depois do resultado.

## Escolhas necessárias que o curso não determina numericamente

- Janela de 60 minutos e confirmação de pivôs por duas velas.
- No desempate de estrutura M1, direção pelo fechamento contra a abertura da janela.
- Escolher o nível estrutural anterior mais recente, sem escolher depois o canal
  que teria produzido o melhor resultado.
- Margem do stop de 10% da largura do canal.
- Filtro binário pela cor atual do diário (preço atual contra abertura do dia),
  uma simplificação do contexto visual do autor. Existe comparação sem esse filtro.
- Espaço de pelo menos uma caixa CA+ZN até a próxima meia linha macro.
- Máximo de 3 operações por dia, uma posição por vez e saída até 12h.
- Capital hipotético US$ 10.000 e risco inicial desejado de 0,5% por operação,
  ajustado ao lote mínimo/step e à margem disponível. Não se reproduz aumento
  agressivo de lote nem se assume que crescimento ilustrativo de conta é repetível.
- Comissão US$ 7 por lote ida e volta; slippage de US$ 0,02 no preço por lado.
  São hipóteses, não custos efetivos confirmados da conta. Há cenários sem essas
  duas parcelas e com custos estressados. Todos conservam o spread histórico.

Essas escolhas tornam a implementação repetível, mas impedem chamá-la de réplica
exata das decisões do autor.

## Alternativas que não são misturadas no cenário principal

Barra elefante/Kid Bengala, padrão lateral, rabelada, antecipação M1 de ciclos
M15, alvo semanal, saídas parciais, execução manual antes do fechamento e
decisões discricionárias ao redor de notícias são opções distintas. O principal
mantém fechamento confirmado, stop/alvo definidos e proteção pelo subciclo.
O curso apresenta várias dessas opções como escolhas, não como regras que
devem ser ligadas ao mesmo tempo.

## Histórico e horários

- Fonte: MT5, servidor `HantecMarketsMU-MT5`, símbolo exato `XAUUSD`.
- Pedido: 28/10/2025 00h até antes de 28/10/2026 00h, no rótulo temporal do servidor.
- Retorno M1: 354.391 barras, primeiro candle 28/10/2025 01h, último
  27/10/2026 23h59. São 258 datas com cotações, incluindo dias parciais/feriados.
- Sem duplicações ou erros OHLC encontrados. Interrupções de sessão e feriados
  não foram preenchidos com preços artificiais.
- O terminal original tinha limite de 100 mil barras. Uma instância separada,
  local, com limite de 1 milhão, forneceu o ano completo sem fechar o original.
- O tick ao vivo tinha rótulo 3h à frente do UTC real. Para os filtros de horário,
  usa-se a hipótese de servidor Nova York +7h, acompanhando o verão americano
  (UTC+2/+3), convertida para `America/Sao_Paulo`. Também há janelas ±1h na
  sensibilidade, pois o histórico completo da política de fuso não foi confirmado.
- D1/H1/M15 são incluídos para conferência. O algoritmo não consulta a máxima,
  mínima ou fechamento final de um dia ainda em formação.

## Execução e limites do veredito

Um sinal só existe depois do fechamento M1. A entrada ocorre na abertura do
minuto seguinte; se houver intervalo entre as barras, o sinal é descartado.
Compra entra no Ask e sai no Bid; venda entra no Bid e sai no Ask aproximado
pelo spread da barra. Os extremos Ask dentro do minuto são uma aproximação.
Stops com gap usam preço adverso; targets não recebem bônus favorável de gap.
O spread das barras é o **mínimo do minuto**, conforme a documentação de
[dados de preço da MetaTrader](https://www.metatrader5.com/en/terminal/help/trading_advanced/price_data).
Usá-lo como spread constante pode subestimar os custos e não permite reproduzir
picos intraminuto.
Quando stop e alvo são tocados no mesmo minuto, o principal prioriza o stop.

Não é um backtest integral de ticks. `check_ticks.py` audita apenas minutos de
saída ambíguos. Os ticks não estavam disponíveis para todos os períodos; uma
auditoria do protótipo está preservada em `audit/`. Isso não é usado para
apresentar o principal como uma simulação de execução real.

O drawdown divulgado é do capital ao fechar operações. A variação patrimonial
intratrade pode ser maior. Nas variantes por fechamento/média, o stop não é uma
garantia de perda máxima: um candle pode fechar além do limite inicial.

O corte de avaliação final é 28/07/2026 (primeiros 9 / últimos 3 meses). Os últimos
3 meses não são uma validação futura nem uma prova fora da amostra de todas as
decisões de modelagem. A mesma pesquisa inspeciona o período inteiro; não houve
otimização de parâmetros por lucro. O intervalo de bootstrap é exploratório e
não cobre a incerteza de execução e de tradução da técnica visual.

## Revisões documentadas

1. Primeiro protótipo: projeções ancoradas na linha, ainda sem a revisão completa
   das aulas. Parâmetros e métricas guardados em `audit/primeiro_prototipo`.
2. Revisão da entrada efetiva: alvo e proteção partem do preço executado.
   Parâmetros e métricas guardados em `audit/projecao_corrigida`.
3. Regra explícita da aula 11: rejeitar vela de rompimento >1,5 canal e projetar
   a nova referência. Esta regra integra a versão principal final.

As alterações foram motivadas pelas aulas e pela revisão de implementação,
não por uma busca para converter um prejuízo em lucro. As sensibilidades são
apresentadas integralmente, sem eleger retrospectivamente a mais lucrativa.

## Referências técnicas

- [MetaQuotes — copy_rates_range](https://www.mql5.com/en/docs/python_metatrader5/mt5copyratesrange_py)
- [MetaQuotes — copy_ticks_range](https://www.mql5.com/en/docs/python_metatrader5/mt5copyticksrange_py)
- [MetaTrader — configuração MaxBars](https://www.metatrader5.com/en/terminal/help/start_advanced/start)
- [Hantec — condições e horário publicado do servidor](https://hmarkets.com/currencies/)
