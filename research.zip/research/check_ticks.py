"""Audit intraminute ordering in ambiguous OHLC exits, not a full tick test."""
import json,pathlib,os
from datetime import datetime,timezone,timedelta
import numpy as np
import pandas as pd
import MetaTrader5 as mt5

ROOT=pathlib.Path(__file__).resolve().parent
trades=pd.DataFrame(json.loads((ROOT/'results'/'trades.json').read_text(encoding='utf-8')))
bars=pd.read_csv(ROOT/'data'/'XAUUSD_M1.csv')
path=pathlib.Path(os.environ['LOCALAPPDATA'])/'FimatheBacktest'/'MT5'/'terminal64.exe'
if not mt5.initialize(path=str(path),portable=True,timeout=30000):raise RuntimeError(mt5.last_error())
out=[]
try:
 for trade_id,t in trades[trades.ambiguous_bar].iterrows():
    timestamp=int(bars.time.iloc[int(t.exit_index)])
    begin=datetime.fromtimestamp(timestamp,timezone.utc)
    ticks=mt5.copy_ticks_range('XAUUSD',begin,begin+timedelta(seconds=59,milliseconds=999),mt5.COPY_TICKS_ALL)
    row={'trade_id':int(trade_id),'server_minute':begin.isoformat(),'ohlc_assumed_first':'STOP',
         'conditional_on_same_trade_levels':True,
         'key':f'{timestamp}|{int(t.side)}|{t.final_stop:.8f}|{t.target:.8f}'}
    if ticks is None or not len(ticks):
        row.update(status='TICKS_INDISPONIVEIS',error=str(mt5.last_error()))
    else:
        valid=ticks[(ticks['bid']>0)&(ticks['ask']>=ticks['bid'])]
        quote=valid['bid'] if t.side==1 else valid['ask']
        stop=quote<=t.final_stop if t.side==1 else quote>=t.final_stop
        target=quote>=t.target if t.side==1 else quote<=t.target
        a=np.flatnonzero(stop);b=np.flatnonzero(target)
        row.update(status='OK',ticks=len(valid),first_tick=int(valid['time_msc'][0]),last_tick=int(valid['time_msc'][-1]),
                   first_stop_tick=int(a[0]) if len(a) else None,
                   first_target_tick=int(b[0]) if len(b) else None,
                   tick_first='STOP' if len(a) and (not len(b) or a[0]<=b[0]) else 'ALVO' if len(b) else 'NENHUM')
        np.savez_compressed(ROOT/'data'/f'ambiguous_trade_{trade_id}.npz',ticks=valid)
    out.append(row)
    print(row,flush=True)
finally:mt5.shutdown()
(ROOT/'results'/'tick_audit.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
