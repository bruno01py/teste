import json, pathlib, time, os
from datetime import datetime, timezone
import pandas as pd
import MetaTrader5 as mt5

ROOT=pathlib.Path(__file__).resolve().parent.parent
OUT=ROOT/'research'/'data'
OUT.mkdir(parents=True,exist_ok=True)
terminal_path=pathlib.Path(os.environ['LOCALAPPDATA'])/'FimatheBacktest'/'MT5'/'terminal64.exe'
if not mt5.initialize(path=str(terminal_path),portable=True,timeout=30000): raise RuntimeError(mt5.last_error())
try:
    symbol='XAUUSD'
    mt5.symbol_select(symbol,True)
    info=mt5.symbol_info(symbol)
    terminal=mt5.terminal_info()
    start=datetime(2025,10,28,tzinfo=timezone.utc)
    # End at last complete day in requested client calendar, avoiding a partial day.
    end=datetime(2026,10,28,tzinfo=timezone.utc)
    meta={'symbol':symbol,'server':mt5.account_info().server,'requested_start':start.isoformat(),'requested_end_exclusive':end.isoformat(),'terminal_maxbars':terminal.maxbars,'symbol_info':info._asdict()}
    for label,tf in [('M1',mt5.TIMEFRAME_M1),('M15',mt5.TIMEFRAME_M15),('H1',mt5.TIMEFRAME_H1),('D1',mt5.TIMEFRAME_D1)]:
        requested_start=datetime(2020,1,1,tzinfo=timezone.utc) if label=='D1' else start
        rates=mt5.copy_rates_range(symbol,tf,requested_start,end)
        if rates is None or not len(rates):
            print(label,'initial',mt5.last_error(),flush=True)
            rates=mt5.copy_rates_from_pos(symbol,tf,0, min(99000,terminal.maxbars-1))
        if rates is None: raise RuntimeError((label,mt5.last_error()))
        df=pd.DataFrame(rates).drop_duplicates('time').sort_values('time')
        df=df[(df.time>=requested_start.timestamp())&(df.time<end.timestamp())]
        df.to_csv(OUT/f'{symbol}_{label}.csv',index=False)
        meta[label]={'bars':len(df),'first':pd.to_datetime(df.time.iloc[0],unit='s',utc=True).isoformat() if len(df) else None,'last':pd.to_datetime(df.time.iloc[-1],unit='s',utc=True).isoformat() if len(df) else None}
        print(label,meta[label],flush=True)
    (OUT/'metadata.json').write_text(json.dumps(meta,indent=2),encoding='utf-8')
finally:
    mt5.shutdown()
