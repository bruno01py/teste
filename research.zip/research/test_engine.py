import unittest
import pandas as pd
from engine import exit_on_bar, simulate, Signal, Costs


class ExecutionTests(unittest.TestCase):
    def test_ambiguous_bar_stop_first(self):
        p,why,amb=exit_on_bar(1,99,102,100,103,98,.2,.02)
        self.assertEqual(why,'STOP');self.assertTrue(amb)
        self.assertAlmostEqual(p,98.98)

    def test_short_uses_ask(self):
        # Bid high is below stop; Ask high reaches it.
        self.assertEqual(exit_on_bar(-1,101,98,100,100.9,99.5,.2,0)[1],'STOP')

    def test_gap_stop_not_filled_at_stale_level(self):
        self.assertEqual(exit_on_bar(1,99,103,97,98,96,.2,0)[0],97)

    def test_target_no_favorable_gap_bonus(self):
        self.assertEqual(exit_on_bar(1,99,103,105,106,104,.2,0)[0],103)

    def test_breakeven_not_applied_retroactively(self):
        df=pd.DataFrame({'time':[0,60,120], 'open':[100,100,102],
                         'high':[100,103,102.2], 'low':[100,99,100.1],
                         'close':[100,102.5,101], 'spread':[20]*3,
                         'brt_minute':[540]*3,'session_day':['2026-01-01']*3,
                         'brt_time':['2026-01-01T09:00:00-03:00']*3})
        s=Signal(0,1,98,105,'test',{'breakeven_trigger':102})
        t=simulate(df,[s],Costs(7,0,1))
        self.assertEqual(t.exit_index.iloc[0],2)
        self.assertEqual(t.exit_reason.iloc[0],'ZERO_A_ZERO')
        self.assertLess(t.net_usd.iloc[0],0) # nominal zero still pays commission.

    def test_next_open_not_signal_close(self):
        df=pd.DataFrame({'time':[0,60], 'open':[100,101], 'high':[100,101.5],
                         'low':[100,100.8],'close':[100,101.2],'spread':[20]*2,
                         'brt_minute':[540]*2,'session_day':['2026-01-01']*2,
                         'brt_time':['2026-01-01T09:00:00-03:00']*2})
        t=simulate(df,[Signal(0,1,98,105,'test',{})],Costs(0,.02,1))
        self.assertAlmostEqual(t.entry.iloc[0],101.22)

    def test_projection_starts_at_effective_fill(self):
        df=pd.DataFrame({'time':[0,60], 'open':[100,101], 'high':[100,101.5],
                         'low':[100,100.8],'close':[100,101.2],'spread':[20]*2,
                         'brt_minute':[540]*2,'session_day':['2026-01-01']*2,
                         'brt_time':['2026-01-01T09:00:00-03:00']*2})
        context={'target_distance':4,'subcycle_distance':2,'next_macro':110}
        t=simulate(df,[Signal(0,1,98,104,'test',context)],Costs(0,.02,1))
        self.assertAlmostEqual(t.target.iloc[0],105.22)
        self.assertAlmostEqual(t.breakeven_trigger_effective.iloc[0],103.22)


if __name__=='__main__': unittest.main()
