"""Reproduce the experiment from the cached broker data; no live order API."""
import json, pathlib, hashlib
from dataclasses import asdict, replace
import numpy as np
import pandas as pd
from engine import Costs, simulate, summary
from strategy import Rules, prepare_data, build_signals

ROOT=pathlib.Path(__file__).resolve().parent
OUT=ROOT/'results'


def block_bootstrap(trades, seed=20261028, repetitions=5000):
    """Moving five-trading-day blocks. Exploratory interval, not a guarantee."""
    dates=pd.to_datetime(trades.entry_time,utc=True).dt.strftime('%Y-%m-%d')
    table=trades.groupby(dates).agg(total_r=('r','sum'),count=('r','size'))
    x=table.total_r.to_numpy(); n=table['count'].to_numpy()
    rng=np.random.default_rng(seed)
    length=5
    starts=rng.integers(0,len(x),size=(repetitions,int(np.ceil(len(x)/length))))
    idx=(starts[:,:,None]+np.arange(length))%len(x)
    idx=idx.reshape(repetitions,-1)[:,:len(x)]
    means=x[idx].sum(axis=1)/n[idx].sum(axis=1)
    return {'mean_r_95pct_interval':np.quantile(means,[.025,.975]).tolist(),
            'bootstrap_fraction_mean_r_positive':float((means>0).mean()),
            'repetitions':repetitions,'block_trading_days':length,
            'warning':'Intervalo exploratorio condicionado a esta amostra, regras e custos.'}


def execute(df,rules,costs,**kwargs):
    signals,channels=build_signals(df,rules)
    trades=simulate(df,signals,costs,force_close_minute=rules.force_close_brt_minute,
                    max_trades_per_day=rules.max_trades_per_day,**kwargs)
    return trades,channels,len(signals)


def main():
    OUT.mkdir(exist_ok=True)
    rules=Rules();costs=Costs()
    protocol={'rules':asdict(rules),'costs':asdict(costs),'initial_equity_usd':10000,
              'risk_fraction':.005,'leverage':50,'calendar_validation_split_server_day':'2026-07-28',
              'rules_not_optimized_for_profit':True,
              'review_amendments':['Target/subcycle anchored to effective fill (lessons 6 at 8:28 and 8 at 2:87).','Lesson 11 at 10m30s: wait after breakout candle larger than 1.5 reference-channel widths.','Prototype results retained under audit; no search for profitable parameters.'],
              'implementation':'mechanical interpretation, not exact discretionary trading',
              'data_sha256':hashlib.sha256((ROOT/'data'/'XAUUSD_M1.csv').read_bytes()).hexdigest()}
    # This file is written before any performance is calculated.
    (OUT/'protocol.json').write_text(json.dumps(protocol,indent=2),encoding='utf-8')
    df=prepare_data(ROOT/'data'/'XAUUSD_M1.csv')
    trades,channels,n=execute(df,rules,costs)
    if trades.empty:raise RuntimeError('No trades; inspect rules/data, do not optimize to force profit.')
    trades.to_json(OUT/'trades.json',orient='records',force_ascii=False,indent=2)
    csv=trades.copy();csv['context']=csv.context.map(json.dumps)
    csv.to_csv(OUT/'trades.csv',index=False,encoding='utf-8-sig')
    pd.DataFrame(channels).to_csv(OUT/'channels.csv',index=False)
    stats=summary(trades);stats.update(block_bootstrap(trades))
    stats['signals']=n;stats['channel_days']=len(channels)
    print('PRIMARY',json.dumps(stats),flush=True)
    # Calendar split fixed before outcomes: last three months reserved.
    split='2026-07-28'
    for key,part in [('first_9_months',df[df.session_day<split]),('last_3_months',df[df.session_day>=split])]:
        # Preserve original integer indexes, needed by simulator.
        sig,_=build_signals(df,rules)
        ids=set(part.index)
        selected=[s for s in sig if s.signal_index in ids]
        t=simulate(df,selected,costs,force_close_minute=rules.force_close_brt_minute,
                   max_trades_per_day=rules.max_trades_per_day)
        stats[key]=summary(t)
    months=pd.to_datetime(trades.entry_time,utc=True).dt.strftime('%Y-%m')
    monthly=trades.groupby(months).agg(trades=('net_usd','size'),net_usd=('net_usd','sum'),total_r=('r','sum'),wins=('net_usd',lambda s:(s>0).sum()))
    monthly.to_csv(OUT/'monthly.csv',encoding='utf-8-sig')
    scenarios=[]
    variants=[('Principal',rules,costs,True),
              ('Spread historico, sem comissao/slippage',rules,Costs(0,0,1),True),
              ('Custo estressado',rules,Costs(14,.10,1.5),True),
              ('Canal M1: 30 minutos',replace(rules,channel_lookback=30),costs,True),
              ('Canal M1: 120 minutos',replace(rules,channel_lookback=120),costs,True),
              ('Macro: 4 divisoes',replace(rules,macro_divisions=4),costs,True),
              ('Macro: 16 divisoes',replace(rules,macro_divisions=16),costs,True),
              ('Grade semanal historica citada nas aulas',replace(rules,macro_low=1762,macro_high=1878,macro_divisions=2),costs,True),
              ('Sem filtro de cor diaria',replace(rules,daily_direction_filter=False),costs,True),
              ('Sem zero a zero',rules,costs,False),
              ('Sem filtro de vela extensa (prototipo)',replace(rules,large_candle_width_limit=0),costs,True),
              ('Janela uma hora antes',replace(rules,start_brt_minute=150,end_entry_brt_minute=570,force_close_brt_minute=660),costs,True),
              ('Janela uma hora depois',replace(rules,start_brt_minute=270,end_entry_brt_minute=690,force_close_brt_minute=780),costs,True)]
    for name,ru,co,be in variants:
        t,_,_=execute(df,ru,co,breakeven=be)
        row={'scenario':name,**summary(t)}
        scenarios.append(row)
        print('SCENARIO',name,row.get('net_usd'),flush=True)
    t,_,_=execute(df,rules,costs,stop_on_close=True)
    scenarios.append({'scenario':'Stop por fechamento (aula 7)',**summary(t)})
    t,_,_=execute(df,rules,costs,stop_on_close=True,moving_average_stop=True,breakeven=False)
    scenarios.append({'scenario':'Stop SMA 30 High/Low (aula 14)',**summary(t)})
    audit_path=OUT/'tick_audit.json'
    if audit_path.exists():
        audit=json.loads(audit_path.read_text())
        priority={r['key']:r['tick_first'] for r in audit if r.get('status')=='OK' and 'key' in r}
        if priority:
            t,_,_=execute(df,rules,costs,tick_priority=priority)
            scenarios.append({'scenario':'Ambiguidades resolvidas onde ha ticks',**summary(t)})
    pd.DataFrame(scenarios).to_csv(OUT/'sensitivity.csv',index=False,encoding='utf-8-sig')
    stats['period_first_server']=str(df.server_time.iloc[0]);stats['period_last_server']=str(df.server_time.iloc[-1])
    stats['bars']=len(df);stats['broker_days']=df.session_day.nunique()
    (OUT/'summary.json').write_text(json.dumps(stats,indent=2),encoding='utf-8')


if __name__=='__main__':main()
