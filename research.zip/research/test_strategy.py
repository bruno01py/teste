import pathlib, unittest
from strategy import prepare_data,build_signals


class CausalityTest(unittest.TestCase):
    def test_removing_future_candles_preserves_past_signals(self):
        path=pathlib.Path(__file__).parent/'data'/'XAUUSD_M1.csv'
        df=prepare_data(path).iloc[:15000]
        prefix=df.iloc[:13500]
        full,_=build_signals(df)
        truncated,_=build_signals(prefix)
        relevant=[s for s in full if s.signal_index<len(prefix)]
        self.assertEqual(relevant,truncated)
        self.assertGreater(len(relevant),0)
        for s in full:
            self.assertLess(s.context['history_end'],s.signal_index)


if __name__=='__main__':unittest.main()
