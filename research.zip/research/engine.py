"""Offline bid/ask OHLC execution model. This module never sends orders."""
from dataclasses import dataclass, asdict
import math
import numpy as np
import pandas as pd


@dataclass(frozen=True)
class Costs:
    commission_round_turn_per_lot: float = 7.0
    slippage_price_per_side: float = 0.02
    spread_multiplier: float = 1.0


@dataclass(frozen=True)
class Signal:
    signal_index: int
    side: int
    stop: float
    target: float
    reason: str
    context: dict


def exit_on_bar(side, stop, target, o, h, l, spread, slippage):
    """Long exits use Bid; short exits use Ask approximated by minute spread.

    Gap stops execute at the adverse opening quote. Target gaps receive only
    the target price. Both touched => stop first, a conservative OHLC bound.
    """
    if side == -1:
        o, h, l = o + spread, h + spread, l + spread
    stop_hit = l <= stop if side == 1 else h >= stop
    target_hit = h >= target if side == 1 else l <= target
    if stop_hit:
        price = min(stop, o) if side == 1 else max(stop, o)
        return price - side * slippage, 'STOP', bool(target_hit)
    if target_hit:
        return target - side * slippage, 'ALVO', False
    return None


def simulate(df, signals, costs=Costs(), initial_equity=10000.0,
             risk_fraction=0.005, contract=100.0, volume_min=0.01,
             volume_step=0.01, leverage=50.0, force_close_minute=17*60,
             trail=False, max_trades_per_day=3, breakeven=True, stop_on_close=False,
             tick_priority=None, moving_average_stop=False):
    """Signals must use only candles <= signal_index. Execute next candle open.

    One position at a time. Every trade closes intraday (no swap). The per-bar
    spread is an approximation, not tick-exact historical executable spread.
    """
    o,h,l,c = (df[k].to_numpy(float) for k in ['open','high','low','close'])
    spread=df['spread'].to_numpy(float)*0.01*costs.spread_multiplier
    minute=df['brt_minute'].to_numpy(int)
    day=df['session_day'].to_numpy()
    ma_high=df.high.rolling(30).mean().to_numpy()
    ma_low=df.low.rolling(30).mean().to_numpy()
    equity=float(initial_equity)
    occupied_until=-1
    trades=[]
    daily_count={}
    for sig in signals:
        i=sig.signal_index+1
        if i >= len(df) or i <= occupied_until or day[i]!=day[sig.signal_index]:
            continue
        if df.time.iloc[i]-df.time.iloc[sig.signal_index]!=60:
            continue
        if daily_count.get(day[i],0)>=max_trades_per_day:
            continue
        side=sig.side
        entry=o[i]+(spread[i] if side==1 else 0)+side*costs.slippage_price_per_side
        initial_stop=sig.stop
        if moving_average_stop:
            initial_stop=ma_low[i-1] if side==1 else ma_high[i-1]+spread[i-1]
            if not np.isfinite(initial_stop):continue
        target=sig.target
        if 'target_distance' in sig.context:
            projected=entry+side*sig.context['target_distance']
            macro=sig.context['next_macro']
            target=min(projected,macro) if side==1 else max(projected,macro)
        be_trigger=(entry+side*sig.context['subcycle_distance']) if 'subcycle_distance' in sig.context else sig.context.get('breakeven_trigger')
        risk_price=side*(entry-initial_stop)
        reward_price=side*(target-entry)
        if risk_price<=0 or reward_price<=0 or equity<=0:
            continue
        risk_per_lot=(risk_price+costs.slippage_price_per_side)*contract+costs.commission_round_turn_per_lot
        volume=math.floor(min(equity*risk_fraction/risk_per_lot,
                             equity*0.9*leverage/(entry*contract))/volume_step)*volume_step
        if volume<volume_min:
            continue
        stop=initial_stop
        be_activated=False
        initial_risk=risk_per_lot*volume
        worst_equity=equity
        ambiguity=False
        for j in range(i,len(df)):
            if moving_average_stop:
                # SMA period/type is an explicit assumption of this optional
                # lesson-14 variant. Compare only at the candle close.
                stop=ma_low[j] if side==1 else ma_high[j]+spread[j]
            # Pessimistic open-position equity before any exit on this candle.
            adverse=l[j] if side==1 else h[j]+spread[j]
            worst_equity=min(worst_equity,equity+side*(adverse-entry)*contract*volume-costs.commission_round_turn_per_lot*volume)
            effective_stop=(-float('inf') if side==1 else float('inf')) if (stop_on_close or moving_average_stop) else stop
            result=exit_on_bar(side,effective_stop,target,o[j],h[j],l[j],spread[j],costs.slippage_price_per_side)
            if result:
                price,why,ambiguity=result
                key=f'{int(df.time.iloc[j])}|{side}|{stop:.8f}|{target:.8f}'
                if ambiguity and tick_priority and tick_priority.get(key)=='ALVO':
                    price=target-side*costs.slippage_price_per_side
                    why='ALVO'
                if why=='STOP' and be_activated: why='ZERO_A_ZERO' if abs(stop-entry)<1e-8 else 'STOP_MOVEL'
                break
            # Optional lesson-7 variant: wait for a close beyond stop, then
            # exit at next opening quote. A target touched earlier still wins.
            close_quote=c[j]+(spread[j] if side==-1 else 0)
            if (stop_on_close or moving_average_stop) and side*(close_quote-stop)<=0:
                if j+1<len(df) and day[j+1]==day[i]:
                    j+=1
                    price=o[j]+(spread[j] if side==-1 else 0)-side*costs.slippage_price_per_side
                else:
                    price=close_quote-side*costs.slippage_price_per_side
                why='STOP_MEDIA_30' if moving_average_stop else 'STOP_FECHAMENTO' if not be_activated else 'ZERO_A_ZERO_FECHAMENTO'
                break
            if minute[j]>=force_close_minute or j+1==len(df) or day[j+1]!=day[i]:
                price=c[j]+(spread[j] if side==-1 else 0)-side*costs.slippage_price_per_side
                why='FIM_SESSAO'
                break
            trigger=be_trigger
            if breakeven and trigger is not None and side*(c[j]-trigger)>=0:
                stop=max(stop,entry) if side==1 else min(stop,entry)
                be_activated=True
            if trail and j>i:
                # Move only AFTER the closed bar; effective on the next bar.
                if side==1 and c[j]>entry+(entry-sig.stop): stop=max(stop,l[j-1])
                if side==-1 and c[j]<entry-(sig.stop-entry): stop=min(stop,h[j-1]+spread[j])
        gross=side*(price-entry)*contract*volume
        net=gross-costs.commission_round_turn_per_lot*volume
        occupied_until=j
        row={**asdict(sig),'target':target,'breakeven_trigger_effective':be_trigger,'entry_index':i,'exit_index':j,'entry':entry,'exit':price,
             'initial_stop':initial_stop,'final_stop':stop,'volume':round(volume,4),
             'gross_usd':gross,'net_usd':net,'risk_usd':initial_risk,
             'r':net/initial_risk,'equity_before':equity,'equity_after':equity+net,
             'worst_equity_bound':worst_equity,'exit_reason':why,
             'breakeven_activated':be_activated,
             'ambiguous_bar':ambiguity,'entry_time':str(df.iloc[i]['brt_time']),
             'exit_time':str(df.iloc[j]['brt_time'])}
        trades.append(row)
        daily_count[day[i]]=daily_count.get(day[i],0)+1
        equity+=net
    return pd.DataFrame(trades)


def summary(trades, initial=10000.0):
    if trades.empty: return {'trades':0}
    p=trades.net_usd
    equity=np.r_[initial,trades.equity_after.to_numpy()]
    peak=np.maximum.accumulate(equity)
    dd=(peak-equity)/peak
    wins=p[p>0].sum(); losses=-p[p<0].sum()
    return dict(trades=len(trades),wins=int((p>0).sum()),losses=int((p<0).sum()),
                win_rate=float((p>0).mean()),net_usd=float(p.sum()),
                return_pct=float((equity[-1]/initial-1)*100),
                profit_factor=float(wins/losses) if losses else None,
                max_closed_drawdown_pct=float(dd.max()*100),
                mean_r=float(trades.r.mean()),total_r=float(trades.r.sum()),
                ambiguous_bars=int(trades.ambiguous_bar.sum()))
