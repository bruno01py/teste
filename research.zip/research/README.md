# Backtest Fimathe / XAUUSD

Experimento offline com Python e dados do MetaTrader 5. **Nenhum script envia ordens.**

Abra `results/RELATORIO.html` para os resultados e os seis gráficos anotados.
O arquivo `REGRAS_E_FONTES.md` explica a relação entre o curso e a implementação.

## Reproduzir com os dados incluídos

Ambiente testado: Python 3.14 no Windows, com versões de `numpy`, `pandas`,
`matplotlib` e `MetaTrader5` fixadas em `requirements.txt`.

```powershell
python -m pip install -r requirements.txt
python test_engine.py
python test_strategy.py
python run_backtest.py
python make_report.py
```

Execute os comandos dentro desta pasta `research`. Os scripts também funcionam
com caminhos absolutos, pois resolvem os arquivos a partir de sua própria pasta.

`results/trades.csv` contém todas as operações, incluindo níveis, contexto do
sinal, lote, custos, resultado em USD e R, horário de entrada e saída.
`results/protocol.json` registra regras, hipóteses e hash SHA-256 do histórico.
`results/sensitivity.csv` contém todas as variantes testadas, sem seleção da melhor.
`results/monthly.csv` contém a evolução mensal.

## Buscar dados no MT5 novamente

Instale também o pacote `MetaTrader5` no Windows. Tenha um terminal conectado à
corretora e habilitado para fornecer dados. O script atual usa a instância local
isolada em `%LOCALAPPDATA%/FimatheBacktest/MT5/terminal64.exe`; ajuste
`terminal_path` em `fetch_data.py` para usar outra instalação.

```powershell
python fetch_data.py
```

As datas solicitadas estão explícitas em `fetch_data.py`: 28/10/2025 até antes de
28/10/2026 no relógio da corretora, excluindo o dia incompleto. O terminal
original estava limitado a 100 mil barras; a instância separada permitiu extrair
o ano M1 completo. Não inclua senhas em código. A conexão usa a sessão local já
autenticada. Não é necessário copiar credenciais para outra máquina para rodar
o backtest offline.

## Áudio e fontes

No ambiente original, `transcripts/` contém transcrições automáticas locais dos 20 vídeos em português,
com tempos em minutos decimais e JSON em segundos. Podem ocorrer erros de
transcrição; foram examinados também quadros das aulas para interpretar canais.
`transcribe.py` usa `faster-whisper`, modelo medium em CUDA, e ffmpeg via
`imageio-ffmpeg`. Transcrições, quadros das aulas e vídeos não integram o ZIP de
reprodução; não são necessários para repetir o backtest com os dados incluídos.

## Limites

Este é o núcleo mecânico de uma técnica que contém decisões visuais. Não equivale
a todos os setups nem às decisões discricionárias do autor. Os candles M1 e o
spread por minuto não substituem uma simulação integral com ticks, latência e
custos executáveis. Comissão e slippage são hipóteses expostas no relatório.

Os protótipos em `audit/` mostram revisões feitas ao conferir as aulas. Não foram
ajustados parâmetros por busca de lucro. Alterar uma hipótese e obter lucro na
mesma amostra não constitui validação independente.
