import os
os.environ['HF_HUB_OFFLINE'] = '1'
import json, pathlib, time, subprocess
import numpy as np
import imageio_ffmpeg
from faster_whisper import WhisperModel, BatchedInferencePipeline

ROOT = pathlib.Path(__file__).resolve().parent.parent
OUT = ROOT / 'research' / 'transcripts'
OUT.mkdir(parents=True, exist_ok=True)
model = WhisperModel('medium', device='cuda', compute_type='int8_float16', local_files_only=True)
pipeline = BatchedInferencePipeline(model=model)
for video in sorted((ROOT / 'videos').glob('*.mp4')):
    target = OUT / (video.name[:2] + '.json')
    if target.exists():
        continue
    print('START', video.name[:2], video.name, flush=True)
    start = time.time()
    raw = subprocess.run([imageio_ffmpeg.get_ffmpeg_exe(),'-v','error','-i',str(video),'-f','s16le','-ac','1','-ar','16000','-'],capture_output=True,check=True).stdout
    audio = np.frombuffer(raw,dtype=np.int16).astype(np.float32)/32768.0
    segments, info = pipeline.transcribe(audio, language='pt', beam_size=3, vad_filter=True, batch_size=4)
    rows=[]
    for s in segments:
        rows.append(dict(start=round(s.start,2), end=round(s.end,2), text=s.text))
    target.write_text(json.dumps(dict(video=video.name, segments=rows), ensure_ascii=False, indent=2), encoding='utf-8')
    (OUT / (video.name[:2]+'.txt')).write_text('\n'.join(f"[{r['start']/60:.2f} min] {r['text']}" for r in rows),encoding='utf-8')
    print('DONE',video.name[:2],round(time.time()-start,1),'seconds',flush=True)
