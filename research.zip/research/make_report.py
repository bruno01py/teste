"""Create local annotated backtest charts and a self-contained HTML report."""
import json, pathlib, html, textwrap
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
plt.rcParams['text.parse_math']=False
from matplotlib.patches import Rectangle
from strategy import prepare_data

ROOT=pathlib.Path(__file__).resolve().parent
OUT=ROOT/'results'
BG='#0d1626';FG='#e7edf8';MUTED='#9eafc7';GREEN='#32d5a0';RED='#ff7585';BLUE='#60a5fa';YELLOW='#f8cc64'


def style(ax):
    ax.set_facecolor(BG);ax.tick_params(colors=MUTED,labelsize=10)
    for spine in ax.spines.values():spine.set_color('#2b3b50')
    ax.grid(alpha=.12,color=MUTED)


def money(value):return f'US$ {value:,.2f}'


def chart_trade(df,t,path,label):
    ei=int(t['entry_index']);xi=int(t['exit_index']);ctx=t['context']
    start=max(int(ctx['history_start']),ei-45);end=min(len(df)-1,xi+20)
    view=df.iloc[start:end+1]
    fig=plt.figure(figsize=(17,9),facecolor=BG)
    gs=fig.add_gridspec(1,2,width_ratios=[3.6,1.5],left=.055,right=.98,top=.85,bottom=.13,wspace=.12)
    ax=fig.add_subplot(gs[0]);notes=fig.add_subplot(gs[1]);style(ax);notes.axis('off')
    winner=t['net_usd']>0;color=GREEN if winner else RED
    side='COMPRA' if t['side']==1 else 'VENDA'
    fig.text(.055,.94,f'{label}  |  XAUUSD M1  |  {side}',color=color,size=23,weight='bold')
    fig.text(.055,.895,f"{t['entry_time'][:16]} a {t['exit_time'][11:16]} (Brasília)  •  Gráfico do backtest com dados MT5",color=MUTED,size=12)
    for idx,row in view.iterrows():
        x=idx-start;co=GREEN if row.close>=row.open else RED
        ax.vlines(x,row.low,row.high,color=co,lw=.7)
        ax.add_patch(Rectangle((x-.32,min(row.open,row.close)),.64,max(abs(row.close-row.open),.025),facecolor=co,edgecolor=co,lw=.5))
    ax.axhspan(ctx['ca_low'],ctx['ca_high'],color=BLUE,alpha=.08)
    ax.axhspan(ctx['box_low'],ctx['box_high'],color=BLUE,alpha=.035)
    for val,name,co in [(ctx['box_low'],'Limite inferior CA+ZN',BLUE),
                        (ctx['box_high'],'Limite superior CA+ZN',BLUE),
                        (t['initial_stop'],'STOP inicial',RED),
                        (t['target'],'ALVO',GREEN),(t['entry'],'ENTRADA',YELLOW)]:
        ax.axhline(val,color=co,lw=1.2,ls='--',label=f'{name}  {val:.2f}')
    ax.legend(loc='upper right',facecolor=BG,edgecolor='#2b3b50',labelcolor=FG,fontsize=9,framealpha=.9)
    if min(view.low.min(),t['initial_stop'])<ctx['next_macro']<max(view.high.max(),t['target']):
        ax.axhline(ctx['next_macro'],color=MUTED,lw=.9,ls=':')
    ax.scatter([ei-start],[t['entry']],marker='^' if t['side']==1 else 'v',color=YELLOW,s=125,zorder=8)
    ax.scatter([xi-start],[t['exit']],marker='X',color=color,s=120,zorder=8)
    ax.annotate('Saída',xy=(xi-start,t['exit']),xytext=(12,25 if winner else -32),textcoords='offset points',
                color=color,size=11,arrowprops={'arrowstyle':'->','color':color})
    if t.get('breakeven_activated'):
        ax.axhline(t['entry'],color=YELLOW,alpha=.5,lw=.7,ls=':')
    ticks=np.linspace(0,len(view)-1,min(8,len(view)),dtype=int)
    ax.set_xticks(ticks,[str(view.brt_time.iloc[x])[11:16] for x in ticks])
    ax.set_xlabel('Horário de Brasília',color=MUTED,labelpad=12)
    ax.set_ylabel('Preço do ouro (USD) • candles Bid',color=MUTED,labelpad=10)
    ax.set_xlim(-2,len(view)+2)
    vals=[view.low.min(),view.high.max(),t['initial_stop'],t['target']]
    span=max(vals)-min(vals);ax.set_ylim(min(vals)-span*.10,max(vals)+span*.15)
    if t['exit_reason']=='ALVO':
        reason='O rompimento teve continuidade. O preço avançou na direção da entrada e alcançou o alvo projetado antes do stop.'
    elif t['exit_reason']=='STOP':
        reason='O rompimento não se sustentou. O preço voltou contra a entrada, atravessou a caixa e atingiu o stop antes do alvo.'
        before=df.iloc[ei:xi]
        if len(before):
            favorable=(before.high.max()-t['entry']) if t['side']==1 else (t['entry']-(before.low+before.spread*.01).min())
            risk=abs(t['entry']-t['initial_stop'])
            reason+=f" Antes do candle de saída, avançou no máximo {max(0,favorable/risk):.2f} R e não confirmou a proteção."
    elif t['exit_reason']=='ZERO_A_ZERO':
        reason='O preço confirmou o subciclo e ativou a proteção. Depois voltou à entrada; comissão e slippage ainda geram custo.'
    else:
        reason='A operação não atingiu o alvo nem o stop até o encerramento programado da sessão. Foi fechada a mercado.'
    sections=[('RESULTADO LÍQUIDO',f"{money(t['net_usd'])}\n{t['r']:+.2f} R  •  {t['volume']:.2f} lote"),
              ('POR QUE ENTROU','Fechamento rompeu CA + zona neutra; direção compatível com a vela diária; espaço até a próxima linha macro.'),
              ('POR QUE GANHOU' if winner else 'POR QUE PERDEU',reason),
              ('EXECUÇÃO',f"Entrada: {t['entry']:.2f}\nSaída: {t['exit']:.2f}\nStop inicial: {t['initial_stop']:.2f}\nAlvo: {t['target']:.2f}\nSaída: {t['exit_reason']}"),
              ('LEITURA DO PRINT','O motivo descreve o movimento observado. Não identifica a causa econômica do preço.')]
    y=1.0
    for head,body in sections:
        notes.text(0,y,head,color=color if head=='RESULTADO LÍQUIDO' else YELLOW,size=10,weight='bold',va='top',transform=notes.transAxes)
        lines='\n'.join(textwrap.fill(line,42) for line in body.split('\n'))
        notes.text(0,y-.035,lines,color=FG,size=12 if head=='RESULTADO LÍQUIDO' else 10.5,va='top',linespacing=1.5,transform=notes.transAxes)
        y-=.045+(lines.count('\n')+1)*.026+.035
    fig.text(.055,.045,'Simulação histórica • spread M1 + comissão US$ 7/lote ida e volta + slippage US$ 0,02 por lado • não é uma ordem real',color=MUTED,size=10)
    fig.savefig(path,dpi=140,facecolor=BG);plt.close(fig)


def overview(trades,stats,monthly):
    fig,axs=plt.subplots(2,1,figsize=(14,8),facecolor=BG,gridspec_kw={'height_ratios':[2,1]})
    for ax in axs:style(ax)
    x=pd.to_datetime(trades.entry_time,utc=True)
    axs[0].plot(x,trades.equity_after,color=GREEN,lw=1.5)
    axs[0].axhline(10000,color=MUTED,ls='--',lw=.8)
    axs[0].set_ylabel('Capital simulado (USD)',color=MUTED)
    axs[0].set_title('XAUUSD • versão automática baseada nas aulas',color=FG,loc='left',pad=18,fontsize=18)
    axs[0].text(.01,.95,f"Líquido {money(stats['net_usd'])}  |  Fator de lucro {stats['profit_factor']:.2f}  |  {stats['trades']} operações",transform=axs[0].transAxes,color=FG,va='top')
    axs[1].bar(monthly.index,monthly.net_usd,color=[GREEN if n>0 else RED for n in monthly.net_usd])
    axs[1].axhline(0,color=MUTED,lw=.8);axs[1].set_ylabel('Resultado mensal USD',color=MUTED)
    axs[1].tick_params(axis='x',rotation=35)
    fig.tight_layout(pad=2);fig.savefig(OUT/'resumo.png',dpi=140,facecolor=BG);plt.close(fig)


def main():
    stats=json.loads((OUT/'summary.json').read_text())
    trades=pd.DataFrame(json.loads((OUT/'trades.json').read_text(encoding='utf-8')))
    df=prepare_data(ROOT/'data'/'XAUUSD_M1.csv')
    monthly=pd.read_csv(OUT/'monthly.csv',index_col=0)
    sensitivity=pd.read_csv(OUT/'sensitivity.csv')
    overview(trades,stats,monthly)
    prints=[]
    for key,mask,label in [('ganho',(trades.net_usd>0)&(trades.exit_reason=='ALVO'),'OPERAÇÃO VENCEDORA'),
                           ('perda',(trades.net_usd<0)&(trades.exit_reason=='STOP'),'OPERAÇÃO PERDEDORA')]:
        group=trades[mask]
        short=group[group.exit_index-group.entry_index<=120]
        if len(short)>=3:group=short
        positions=np.linspace(0,len(group)-1,min(3,len(group)),dtype=int)
        for k,pos in enumerate(positions,1):
            t=group.iloc[pos].to_dict();filename=f'{key}_{k}.png'
            chart_trade(df,t,OUT/filename,label)
            prints.append({'file':filename,'kind':key,'trade_id':int(group.index[pos]),'entry_time':t['entry_time'],'net_usd':t['net_usd']})
    (OUT/'prints_index.json').write_text(json.dumps(prints,indent=2,ensure_ascii=False),encoding='utf-8')
    profitable=stats['net_usd']>0
    conclusion=('A versão automática teve lucro líquido nesta amostra.' if profitable else 'A versão automática não foi lucrativa nesta amostra.')
    ci=stats['mean_r_95pct_interval']
    cards=[('Resultado líquido',money(stats['net_usd'])),('Retorno',f"{stats['return_pct']:.2f}%"),
           ('Operações',str(stats['trades'])),('Acerto líquido',f"{100*stats['win_rate']:.1f}%"),
           ('Fator de lucro',f"{stats['profit_factor']:.2f}"),('Drawdown em fechamentos',f"{stats['max_closed_drawdown_pct']:.2f}%")]
    table=sensitivity[['scenario','trades','net_usd','profit_factor','max_closed_drawdown_pct']].copy()
    table.columns=['Cenário','Operações','Líquido USD','Fator de lucro','DD fechado %']
    tablehtml=table.to_html(index=False,float_format=lambda n:f'{n:.2f}',border=0)
    gallery=''.join(f'<figure><a href="{p["file"]}"><img src="{p["file"]}"></a><figcaption>{p["kind"].capitalize()} • {html.escape(p["entry_time"][:16])} • {money(p["net_usd"])}</figcaption></figure>' for p in prints)
    protocol=json.loads((OUT/'protocol.json').read_text())
    body=f'''<!doctype html><html lang="pt-BR"><meta charset="utf-8"><title>Backtest XAUUSD — Fimathe</title>
<style>body{{background:{BG};color:{FG};font:17px/1.6 system-ui;margin:40px auto;max-width:1200px;padding:0 24px}}h1{{font-size:36px}}h2{{margin-top:48px}}a{{color:{BLUE}}}.muted{{color:{MUTED}}}.cards{{display:grid;grid-template-columns:repeat(3,1fr);gap:16px}}.card{{padding:20px;background:#16243a;border-radius:10px}}.card strong{{display:block;font-size:26px}}img{{max-width:100%;border-radius:10px}}table{{border-collapse:collapse;width:100%;font-size:14px}}td,th{{padding:12px;text-align:left;border-bottom:1px solid #31425c}}figure{{margin:24px 0}}.notice{{padding:20px;border-left:4px solid {YELLOW};background:#16243a}}code{{color:{YELLOW}}}</style>
<p class="muted">Pesquisa histórica • Python + MetaTrader 5 • HantecMarketsMU-MT5</p>
<h1>Backtest XAUUSD: núcleo mecânico da Fimathe</h1>
<p><strong>{conclusion}</strong> O resultado vale para as regras e custos descritos aqui. O curso contém escolhas visuais e setups opcionais; este teste não equivale a reproduzir todas as decisões do autor.</p>
<p>Período solicitado: últimos 12 meses. Dados: {stats['period_first_server']} a {stats['period_last_server']} no relógio da corretora; {stats['bars']:,} candles M1, {stats['broker_days']} dias com cotações.</p>
<div class="cards">{''.join(f'<div class="card">{a}<strong>{b}</strong></div>' for a,b in cards)}</div>
<p>Capital inicial hipotético US$ 10.000, risco 0,5% do capital por operação, lotes reais mínimos de 0,01, uma posição por vez, alavancagem máxima 1:50. Resultados com reinvestimento e arredondamento do lote.</p>
<img src="resumo.png" alt="Curva de capital e resultados mensais">
<h2>O que foi implementado</h2>
<ol><li>Mapa macro fixo anterior à amostra: fundo 1803,98, topo 2077,49, divisão em 8 canais e respectivas metades, derivados do exemplo da aula 2 (2023). A grade é estendida em preço, sem usar máximas ou mínimas futuras.</li>
<li>Às 03h30 de Brasília, selecionar o canal M1 nos 60 minutos anteriores por pivôs com 2 candles de confirmação. Manter a marcação durante o dia. Esta escolha objetiva substitui o desenho manual do curso.</li>
<li>Construir canal de referência e zona neutra. Entrar após fechamento que rompe a caixa, na abertura seguinte, com filtro pela cor atual da vela diária e espaço mínimo de um subciclo até o próximo nível macro.</li>
<li>Se a vela de rompimento tiver amplitude maior que 1,5 canal de referência, não entrar: projetar um canal na direção do movimento e aguardar novo rompimento. A amplitude considera máxima menos mínima; esta convenção explicita a regra da aula 11.</li>
<li>Stop fora da caixa, com margem de 10% da largura do canal. Alvo de dois níveis (cada nível equivale à caixa CA+ZN), projetado da entrada efetiva e limitado pela próxima meia linha macro.</li>
<li>Após fechamento além do primeiro nível, mover o stop para a entrada, válido a partir do próximo candle. O zero nominal ainda paga os custos.</li>
<li>Entradas de 03h30 a 10h30 de Brasília, máximo de 3 operações por dia, encerrar posições até 12h. Sem carregamento noturno.</li></ol>
<p class="notice">Os parâmetros de pivôs, janela, limite diário, margem do stop e filtro binário da vela diária são decisões de modelagem. O autor escolhe canais e contexto visualmente. Não foi feita uma busca de parâmetros para obter lucro.</p>
<h2>Custos e qualidade da simulação</h2>
<p>Usado o spread histórico informado em cada candle M1, comissão hipotética de US$ 7 por lote na ida e volta, slippage de US$ 0,02 no preço por lado e contrato de 100 onças/lote. Comissão e slippage são hipóteses, não a confirmação do custo da sua conta. Vendas são encerradas no Ask, compras no Bid. Stops com gap têm execução adversa; quando stop e alvo cabem no mesmo candle, prevalece o stop ({stats['ambiguous_bars']} casos no cenário principal).</p>
<p>O spread do candle M1 é o mínimo registrado no minuto, segundo a <a href="https://www.metatrader5.com/en/terminal/help/trading_advanced/price_data">documentação da plataforma</a>. Usá-lo como constante pode subestimar o custo executável. Ele não contém a sequência de ticks nem os picos de spread. O drawdown mostrado usa capital no fechamento das operações; o drawdown intratrade pode ser maior. Não há simulação de latência, rejeição de ordens ou impacto de mercado. Não foram enviados pedidos de negociação ao MT5.</p>
<p>Foi detectado no terminal um deslocamento de +3h entre o tick e o UTC real. Horários de Brasília usam a hipótese de servidor alinhado a Nova York +7h (UTC+2/+3), com ajuste de horário de verão. Uma sensibilidade de horários deve ser considerada se a política histórica da corretora diferir.</p>
<h2>Consistência e incerteza</h2>
<p>Expectativa média: {stats['mean_r']:.3f} R por operação. Intervalo exploratório de 95% por reamostragem de blocos de cinco dias com operações: [{ci[0]:.3f}; {ci[1]:.3f}] R. Este intervalo depende da amostra, das regras e dos custos; não mede todas as incertezas da estratégia.</p>
<p>Primeiros 9 meses: {stats['first_9_months']['trades']} operações, {money(stats['first_9_months']['net_usd'])}, fator de lucro {stats['first_9_months']['profit_factor']:.2f}. Últimos 3 meses (corte fixado em 28/07/2026): {stats['last_3_months']['trades']} operações, {money(stats['last_3_months']['net_usd'])}, fator de lucro {stats['last_3_months']['profit_factor']:.2f}. Cada subperíodo começa com US$ 10.000; esses valores não se somam ao lucro anual.</p>
<p>Essa é uma separação temporal para comparação, não um teste futuro independente: as regras foram revisadas durante a mesma pesquisa. A variante de médias usa SMA 30 High/Low; o tipo simples é uma hipótese. Nas saídas por fechamento/média, a perda pode ultrapassar o risco inicial se a vela fechar além do stop.</p>
<p>As alternativas abaixo avaliam sensibilidade. Nenhuma foi escolhida retrospectivamente como “a estratégia”. A revisão das aulas corrigiu a projeção de alvo/subciclo a partir da entrada efetiva e acrescentou o filtro de vela extensa da aula 11. Parâmetros e métricas intermediárias estão preservados na pasta <code>audit</code>; as revisões seguiram as aulas, sem busca de parâmetros por lucro.</p>{tablehtml}
<h2>Operações anotadas</h2><p>Três alvos vencedores e três stops perdedores, escolhidos em posições inicial, central e final de cada grupo. Quando há exemplos suficientes, usa-se duração até 120 minutos para legibilidade. São ilustrações, não uma amostra estatística. Os motivos escritos nos prints descrevem a trajetória do preço e a regra de saída, não uma causa econômica comprovada.</p>{gallery}
<h2>Arquivos e reprodução</h2><p><a href="trades.csv">Todas as operações CSV</a> • <a href="monthly.csv">Resultados mensais</a> • <a href="sensitivity.csv">Sensibilidade</a> • <a href="protocol.json">Protocolo e parâmetros</a> • <a href="../REGRAS_E_FONTES.md">Regras, aulas e limitações</a></p>
<p>Na pasta <code>research</code>, executar <code>python run_backtest.py</code> e depois <code>python make_report.py</code>. Para atualizar o histórico: <code>python fetch_data.py</code>, com MT5 conectado. Confira o README para caminhos e dependências.</p>
<h2>Fontes</h2><p><a href="https://www.youtube.com/playlist?list=PLWhqc48nlRWKWGyAfGr0iLpwtsGexhnaZ">Playlist original</a> e transcrições locais das aulas. Integração de dados conforme <a href="https://www.mql5.com/en/docs/python_metatrader5/mt5copyratesrange_py">documentação da MetaQuotes</a>. Horário do servidor: <a href="https://hmarkets.com/currencies/">condições publicadas pela Hantec</a>, comparadas com o relógio observado no terminal.</p>
</html>'''
    (OUT/'RELATORIO.html').write_text(body,encoding='utf-8')
    print('REPORT',OUT/'RELATORIO.html')


if __name__=='__main__':main()
